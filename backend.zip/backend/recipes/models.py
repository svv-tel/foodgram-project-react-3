from django.contrib.auth import get_user_model
from django.db import models

User = get_user_model()


class Tag(models.Model):
    name = models.CharField(
        verbose_name='Название тега', unique=True,
        max_length=200
    )
    colour = models.CharField(
        verbose_name='Цвет в HEX', unique=True,
        max_length=7
    )
    slug = models.SlugField(unique=True, max_length=200)

    class Meta:
        ordering = ('name',)

    def __str__(self):
        return self.name


class Ingredient(models.Model):
    name = models.CharField(
        verbose_name='Название ингредиента', unique=True,
        max_length=100
    )
    measurement_unit = models.CharField(
        verbose_name='Параметр измерения ингредиента', unique=True,
        max_length=100
    )

    class Meta:
        ordering = ('name',)

    def __str__(self):
        return self.name


class Recipe(models.Model):
    '''Модель рецепта'''
    author = models.ForeignKey(
        User, verbose_name='Автор рецепта',
        on_delete=models.CASCADE,
        related_name='recipes',
    )
    name = models.CharField(verbose_name='Название рецепта', max_length=200)
    image = models.ImageField(
        verbose_name='Картинка',
        upload_to='recipes/',
        blank=True,
        null=True,
    )
    text = models.TextField(verbose_name='Описание рецепта', )
    ingridient = models.ManyToManyField(Ingredient,
                                         verbose_name='Ингридиенты рецепта', )
    tag = models.ManyToManyField(Tag, verbose_name='Теги рецепта', )
    cooking_time = models.PositiveSmallIntegerField(
        verbose_name='Время приготовления по рецепту', )
    pub_date = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-pub_date',)

    def __str__(self):
        return self.name
